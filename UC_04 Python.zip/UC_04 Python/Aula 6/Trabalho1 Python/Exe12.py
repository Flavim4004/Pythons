resp=int(input("Qual serie voce viu nesse final de semana fih? \n [1]Sandman \n [2]Sex Education \n [3]Game of thrones \n [4]Dota \n [5]This is us 6 temp \n"))
if(resp==1):
    print("Sandman")
elif(resp==2):
    print("Sex Education")
elif(resp==3):
    print("Game of Thrones")
elif(resp==4):
    print("Dota")
elif(resp==5):
    print("This is Us 6 ")
else:
    print("Outra Opção interessante fih")