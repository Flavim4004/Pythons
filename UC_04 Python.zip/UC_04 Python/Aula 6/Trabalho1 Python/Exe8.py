salmin=float(1293.20)
sal=float(input("Digite o seu salario fih! \n"))
cal1=(sal/salmin)

print("Serao necessarios " + str(cal1) + " Salarios minimos para alcançar o salario digitado que é " + str(sal))