import random
s=random.randint(-10,10)
if(s < 0):
    print( str(s) +" E negativo fih")
else:
    print( str(s) +" E positivo fih")