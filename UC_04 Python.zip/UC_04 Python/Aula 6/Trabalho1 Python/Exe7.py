n1=int(input("Digte um numero fih! \n"))
n2=int(input("Digite um outro numero fih! \n"))
if(n1 == n2):
    nc=int(n1 + n2)
    print("A Variavel C é " + str(nc))
elif(n1 != n2):
    n3=int(n1-n2)
    print("A Variavel C é " + str(n3))