cont=int(0)
a=str("")
for cont in range (0,5,2):
    a=str(input("Digite seu nome \n "))