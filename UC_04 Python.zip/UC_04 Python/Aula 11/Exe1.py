cont=int(0)
nome=str("")
tel=int(0)
for cont in range(0,3,1):
    nome=str(input("Qual seu nome fih? \n "))
    tel=int(input("Qual seu telefone fih \n "))
    print(f"O nome cadastrado foi {nome}  e o telefone foi {tel} \n ")