cont=int(0)
for cont in range(0,2,1):
    raca=str(input("Qual a raça do seu cachorro fih? \n"))
    port=str(input("Qual e o port da sua raça de cachorro  fih? \n "))
    cor=str(input("Qual a cor do pelo do seu cachorro fih ? \n"))
    print(f"O cachorro da raça {raca} e da cor {cor} e porte {port} cadastrado com sucesso.")
