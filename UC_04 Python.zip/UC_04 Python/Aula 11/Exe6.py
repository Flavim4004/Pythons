cont=int(0)
for cont in range(0,3,1):
    nome=str(input("Qual seu nome fih! \n"))
    print(f"{nome} cadastrado com sucesso \n")