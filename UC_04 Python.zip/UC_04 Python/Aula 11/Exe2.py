cont=int(0)
for cont in range(0,3,1):
    pes=str(input("Qual seu nome fih? \n"))
    tel1=int(input("Qual seu numero fih? \n"))
    tel2=int(input("Qual seu numero reserva fih? \n"))
    print(f"O nome {pes} foi cadastrado com sucesso com o telefone 1 {tel1} cadastrado com sucesso e o telefone 2 {tel2} cadastrado com sucesso ")


    