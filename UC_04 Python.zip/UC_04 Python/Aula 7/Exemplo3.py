print("O Que voçe prefere fih")
print("[1] Pastel de carne ")
print("[2] Pastel de Queijo")
print("[3] Pastel de Frango")
r=int(input(""))
match r:
    case 1:
        print("Gosta de Carne")
    case 2:
        print("Gosta de Queijo")
    case 3:
        print("Gosta de Frango")
