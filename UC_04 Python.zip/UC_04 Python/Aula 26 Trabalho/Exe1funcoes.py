def exercito(sexo,idade,nacao):
    if(sexo ==1 and idade >= 18 and nacao == "Brasieliro"):
        print("Apto")
    else:
        print("Não Apto")