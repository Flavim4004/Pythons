def ano(dia,sal):
    if(dia == 1):
        cal=sal+(sal*0.10)
        print(f"O preço final nessa data é {cal} ")
    if(dia == 2):
        cal=sal+(sal*0.20)
        print(f"O preço final nessa data é {cal}")
    if(dia == 3):
        cal=sal+(sal*0.05)
        print(f"O preço final nessa data é {cal}")
    if(dia == 4):
        cal=sal-(sal*0.30)
        print(f"O preço final nessa data é {cal}")
    if(dia == 5):
        cal=sal-(sal*0.05)
        print(f"O preço final nessa data é {cal}")