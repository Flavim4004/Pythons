def FabioPorchat(escolha):
    idade=int(input("Quantos anos voce tem fih! \n"))
    cidade=str(input("Qual sua cidade fih! \n "))
    print(f"você tem {idade} anos e mora na cidade {cidade} ")
def DaniloGentili(escolha):
    peso=int(input("Qual o seu peso fih! \n"))
    altura=float(input("Qual a sua altura fih! \n"))
    print(f"sua altura é {altura} e seu peso é {peso}")
def Rafinhabastos(escolha):
    cabelo=str(input("Qual a cor do seu cabelo fih! \n"))
    pe=int(input("Qual o tamanho do teu pe fih! \n"))
    print(f"a cor do seu cabelo é {cabelo} e sua altura é {pe}")