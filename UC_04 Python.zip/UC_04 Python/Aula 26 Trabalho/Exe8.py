import Exe8funcoes
serie=int(input("Qual serie voce viu esse final de semana fih! \n [1]Rick and morty \n [2]Andor \n [3]To be hero X \n [4]Dungeon meshi \n"))
Exe8funcoes.escolha(serie)