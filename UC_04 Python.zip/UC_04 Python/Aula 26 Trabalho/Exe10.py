import Exe10funcoes
terra=int(input("Qual seu peso na terra fih! \n"))
escolha=int(input("Em qual planeta voce quer ver seu peso fih! \n [1]Mercurio \n [2]Venus \n [3]Marte \n [4]Jupter \n [5]Saturno \n [6]Urano \n "))
Exe10funcoes.cal(terra,escolha)