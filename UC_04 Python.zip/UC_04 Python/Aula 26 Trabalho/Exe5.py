cont=int(0)
somapar=int(0)
somaimpar=int(0)
num=[0,0,0]
for cont in range(0,3,1):
    num[cont]=int(input("Digite um numero fih! \n"))
    if(num[cont] %2 ==0 ):
        somapar=somapar+num[cont]
    else:
        somaimpar=somaimpar+num[cont]
print(f"a soma dos números pares é {somapar} e a soma dos números impares é {somaimpar}")