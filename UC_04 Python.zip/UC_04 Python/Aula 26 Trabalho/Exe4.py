cont=int(0)
maior=int(0)
salario=[0,0,0,0]
for cont in range(0,4,1):
    salario[cont]=int(input("Qual o seu salario fih! \n"))
    if(salario[cont]>maior):
        maior=salario[cont]
print(f"O maior salario entre as pessoas  citadas é {maior}")