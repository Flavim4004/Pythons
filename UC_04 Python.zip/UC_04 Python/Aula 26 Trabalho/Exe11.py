import Exe11funcoes
escolha=int(input("Escolha um humorista fih! \n [1]FabioPorchat \n [2]DaniloGentili \n [3]Rafinha bastos \n"))
if(escolha == 1):
    Exe11funcoes.FabioPorchat(escolha)
if(escolha == 2):
    Exe11funcoes.DaniloGentili(escolha)
if(escolha == 3):
    Exe11funcoes.Rafinhabastos(escolha)