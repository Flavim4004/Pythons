def escolha(serie):
    if(serie ==1):
        print("Um gênio alcoólatra e seu neto viajam por multiversos em aventuras perigosas e existenciais.")
    if(serie ==2):
        print("Um agente rebelde luta contra o Império Galáctico em uma missão de espionagem tensa e cheia de suspense.")
    if(serie ==3):
        print("Em um mundo repleto de heróis brilhantes, a confiança dos fãs é o que transforma heróis em super-heróis.")
    if(serie ==4):
        print("Um grupo de aventureiros encontra um jeito de cozinhar monstros em um calabouço.")

