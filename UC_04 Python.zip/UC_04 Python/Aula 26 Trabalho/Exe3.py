cont=int(0)
contpar=int(0)
continpar=int(0)
num=[0,0,0]
for cont in range(0,3,1):
    num[cont]=int(input("Digite um numero fih! \n"))
    if(num[cont] %2 ==0):
        contpar=contpar+1
    if(num[cont] %2 ==1):
        continpar=continpar+1
print(f"foram encontrados {contpar} números pares e {continpar} números impares")