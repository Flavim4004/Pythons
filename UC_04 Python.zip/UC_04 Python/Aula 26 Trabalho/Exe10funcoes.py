def cal(terra,escolha):
    if(escolha == 1):
        cal=terra*0.37
        print(f"Seu peso nesse planeta seria {cal}")
    if(escolha == 2):
        cal=terra*0.88
        print(f"Seu peso nesse planeta seria {cal}")
    if(escolha == 3):
        cal=terra*0.38
        print(f"Seu peso nesse planeta seria {cal}")
    if(escolha == 4):
        cal=terra*2.64
        print(f"Seu peso nesse planeta seria {cal}")
    if(escolha == 5):
        cal=terra*1.15
        print(f"Seu peso nesse planeta seria {cal}")
    if(escolha == 6):
        cal=terra*1.17
        print(f"Seu peso nesse planeta seria {cal}")