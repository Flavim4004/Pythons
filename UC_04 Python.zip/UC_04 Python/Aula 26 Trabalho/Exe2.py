cont=0
soma=int(0)
media=int(0)
media2=int(0)
num=[0,0,0]
for cont in range(3):
    num[cont]=int(input("Digite um numero fih! \n"))
    
    soma=soma+num[cont]
media=float(soma/3)
media2=float(media*2)
if(soma > media2):
    print(f"Verdadeiro \n a soma e {soma} \n o dobro da media {media2}")
else:
    print(f"Falso \n a soma e {soma} \n o dobro da media {media2}")