
cont=int(0)
v=[0,0,0]
for cont in range(0,3,1):
    nome=str(input("Qual o seu nome fih! \n"))
    salario=str(input("Qual seu salario fih! \n"))
    print(f"Nome {nome} cadastrado com sucesso \n Salario {salario} cadastrado com sucesso")
        