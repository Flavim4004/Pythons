import Exe9funcoes
sal=int(input("Quanto voce vai gastar fih! \n"))
dia=int(input("Em que epoca estamos fih! \n [1]Carnaval \n [2]ferias \n [3]Dia das crianças  \n [4]Black friday \n [5]Natal \n"))
Exe9funcoes.ano(dia,sal)