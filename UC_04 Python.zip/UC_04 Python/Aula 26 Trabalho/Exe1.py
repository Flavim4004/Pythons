import Exe1funcoes
idade=int(input("Qual sua idade fih! \n"))
sexo=int(input("Qual seu sexo fih! \n [1]Masculino \n [2]Feminino \n"))
nacao=str(input("Qual a sua nacionalidade fih! \n"))
Exe1funcoes.exercito(sexo,idade,nacao)