contpar=int(0)
somapar=int(0)
maiorpar=int(0)
cont=int(0)
num=[0,0,0,0]
for cont in range(0,4,1):
    num[cont]=int(input("digite um numero fih! \n"))
    if(num[cont] %2 == 0 ):
        somapar=somapar+num[cont]
        contpar=contpar+1
    if(num[cont] %2 == 0 and num[cont] > maiorpar):
        maiorpar=num[cont]
print(f"Foram digitados {contpar} números pares \n A soma desses números pares é {somapar} \n O maior numero par é {maiorpar} \n")       