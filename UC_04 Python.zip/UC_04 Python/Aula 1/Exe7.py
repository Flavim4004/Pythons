a=int(input("Escolha um numero fih!"))
b=int(a-1)
c=int(a+1)
print("O numero é " + str(a) + " seu antecessor é " + str(b) + " Seu sucessor é " + str(c))