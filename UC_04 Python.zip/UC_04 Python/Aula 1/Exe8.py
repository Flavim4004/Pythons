a=int(input("Qual sua idade fih!"))
print("Sua idade é " + str(a))