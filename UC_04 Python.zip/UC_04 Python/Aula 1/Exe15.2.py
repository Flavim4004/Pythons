cel=float(input("Qual a temperatura no momento fih?"))
f=float(((9*cel)/5)+32)
print("A temperatura em fareheint" + str(f))