a = float(input("Qual seu salario fih?"))
b = float(a * 1.33)
total = float(a+b)
print("O total é " + str(total))