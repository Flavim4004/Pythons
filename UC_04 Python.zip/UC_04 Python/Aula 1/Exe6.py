a=str(input("Qual seu nome fih!"))
b=str(input("Qual seu sexo fih!"))
c=int(input("Qual sua idade fih!"))
print("O nome é " + str(a) + " o sexo é " + str(b) + " e a idade " + str(c))
