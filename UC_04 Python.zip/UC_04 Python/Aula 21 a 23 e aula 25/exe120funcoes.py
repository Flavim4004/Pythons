def pouN(num):
    if(num > 0):
        p=num
        print(f"O valor é maior que zero logo e postivo {p}")
        return p
    if(num <0):
        n=num
        print(f"O valor é menor que zero logo e negativo {n}")
        return n
    if(num == 0):
        o=num
        print(f"O valor deu zero logo é {o}")
        return o

    