import exe127funcoes
trab=int(input("Qual sua profissao fih! \n [1]Policial ou Médico \n [2]Magico ou Coach \n"))
exe127funcoes.analise(trab)