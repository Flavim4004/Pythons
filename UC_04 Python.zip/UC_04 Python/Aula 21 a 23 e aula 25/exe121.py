import exe121funcoes
num=int(input("Digite um numero fih! \n"))
exe121funcoes.analisar(num)