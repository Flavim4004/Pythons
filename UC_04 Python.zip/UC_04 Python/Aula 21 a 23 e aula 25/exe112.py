import exe112funcoes
a=int(input("Digite um numero fih! \n"))
b=int(input("Digite outro numero fih! \n"))
c=int(input("Digite outro numero fih! \n"))
exe112funcoes.analisar(a,b,c)

