import exe125funcoes
num=int(input("Digite um numero fih! \n"))
num2=int(input("Digite um outro numero fih! \n"))
exe125funcoes.dobrar(num,num2)

