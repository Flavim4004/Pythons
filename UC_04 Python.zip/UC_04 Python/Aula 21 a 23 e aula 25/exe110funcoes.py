def soma(a,b):
    soma=int(a+b)
    print(f"A Adição de {a}+{b}={soma}")
def subtracao(a,b):
    sub=int(a-b)
    print(f"A Subtração de {a}-{b}={sub}")
def multiplicacao(a,b):
    mult=int(a*b)
    print(f"A Multiplicação de {a}x{b}={mult}")
def dvisao(a,b):
    div=int(a/b)
    print(f"A Divisão de {a}/{b}={div}")