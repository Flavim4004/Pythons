def mostrar(num1,num2):
    while(num1 != num2):
        num1=num1+1
        print(num1)