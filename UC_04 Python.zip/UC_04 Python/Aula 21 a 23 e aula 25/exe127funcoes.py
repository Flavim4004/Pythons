def analise(trab):
    if(trab == 1):
        print("Voce recebe 2000 fih! é sua renda anual seria 24000 \n")    
    if(trab == 2):
        print("Voce recebe 1500 fih!  é sua renda anual seria 18000 \n")
    else:
        print("Voce recebe 500 e sua renda anual e desconheçida ")
