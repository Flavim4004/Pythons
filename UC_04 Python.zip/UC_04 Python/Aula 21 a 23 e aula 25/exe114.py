import exe114funcoes
idade=int(input("Qual sua idade fih! \n"))
sexo=str(input("Qual seu sexo fih! \n"))
nome=str(input("Qual seu nome fih! \n"))
exe114funcoes.cadastro(idade,sexo,nome)