def analisar(a,b,c):
    maior=int(0)
    if(a>maior):
        maior=a
    if(b>maior):
        maior=b
    if(c>maior):
        maior=c
        
    print(f"O maior numero é {maior}")
    menor=int(99999)
    if(a<menor):
        menor=a
    if(b<menor):
        menor=b
    if(c<menor):
        menor=c
    print(f"O menor numero é {menor}")

    
