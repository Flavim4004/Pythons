import exe129funcoes
reais=float(input("Quanto tu tem na conta fih! \n"))
con=int(input("Qual a conversão fih \n [1]Dolar \n [2]Euro \n [3]Yene \n"))
exe129funcoes.conversao(reais,con)