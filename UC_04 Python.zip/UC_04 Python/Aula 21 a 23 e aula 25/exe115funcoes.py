def antecessor(a):
    cal1=int(a-1)
    cal3=int(a+1)
    print(f"O antecessor desse numero A é {cal1}")
    print(f"O sucessor desse numero A é {cal3}")
    
def sucessor(b):
    cal4=int(b+1)
    cal2=int(b-1)
    print(f"O sucessor desse numero B é {cal4}")
    print(f"O antecessor desse numero B é {cal2}")