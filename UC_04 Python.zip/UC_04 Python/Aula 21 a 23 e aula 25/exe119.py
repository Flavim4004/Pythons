import exe119funcoes
num1=int(input("Digite um numero fih!\n"))
num2=int(input("Digite outro numero fih! \n"))
exe119funcoes.mostrar(num1,num2)