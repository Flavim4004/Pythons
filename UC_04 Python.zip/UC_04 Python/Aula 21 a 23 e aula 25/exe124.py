import exe124funcoes
num=int(input("Digite um numero fih! \n"))
num2=int(input("Digite um numero fih! \n"))
num3=int(input("Digite um numero fih! \n"))
exe124funcoes.analise(num,num2,num3)