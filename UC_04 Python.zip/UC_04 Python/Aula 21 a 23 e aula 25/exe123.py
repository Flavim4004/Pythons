import exe123funcoes
valor=int(input("Quanto tu vai gastar fih! \n"))
pag=int(input("Qual a forma de pagamento fih! \n [1]Vista [2]Prazo \n [3]Cartão Parcelas \n"))
exe123funcoes.analise(valor,pag)