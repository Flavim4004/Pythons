import exe111funcoes
km=int(input("Quantos km vc ta rodando fih! \n"))
dias=int(input("A quantos dias ta rodando essa km? \n"))
exe111funcoes.cobrar(km,dias)