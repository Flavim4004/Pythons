def conversao(reais,con):
    if(con==1):
        dolar=float(reais*5.43)
        print(f"você tem equivalente a {dolar} dólares")
    if(con==2):
        euro=float(reais*6.41)
        print(f"você tem equivalente a {euro} euros")
    if(con==3):    
        yene=float(reais*0.038)
        print(f"Você tem equivalente a {yene} iene")
    