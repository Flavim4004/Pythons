def acabou():
    print("Acabou logica de programação fih! \n")