def valor1(num1,num2):
    maior=int(0)
    if(num1 > maior):
        maior=num1
    if(num2 >maior):
        maior=num2
    print(f"O maior numero é {maior}")
    return maior
def valor2(num1,num2):
    menor=int(99999)
    if(num1<menor):
        menor=num1
    if(num2<menor):
        menor=num2
    print(f"O menor numero é {menor}")
    return menor