def demitido(salario):
    ferias=float(salario*1.33)
    
    demi=float(salario+ferias)
    print(f"Você receberá no total {demi} que inclui o salario do mês mais as suas ferias")