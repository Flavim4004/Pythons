def miojo():
    print("Colocar miojo na agua quente \n")
    print("Aguardar 3 minutos e desligar o fogo \n")

def paoComSalame():
    print("Abrir o pão e colocar o salame \n ")

def soma(a,b):
    soma=int(a+b)
    print(f"A soma é {soma}")
def maior(a,b):
    maior=int(0)
    if(a > maior):
        maior=a
    if(b > maior):
        maior=b
    print(f"O maior é {maior}")

def dobrar(a):
    dobrar = int(a*2)
    return dobrar