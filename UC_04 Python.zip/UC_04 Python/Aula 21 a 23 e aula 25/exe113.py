import exe113funcoes
salario=int(input("Qual seu salario fih! \n"))
exe113funcoes.demitido(salario)