import exe115funcoes
a=int(input("Digite um numero fih! \n"))
exe115funcoes.antecessor(a)
b=int(input("Digite um numero fih! \n"))

exe115funcoes.sucessor(b)