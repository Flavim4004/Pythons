import Exemplo7funcoes

Exemplo7funcoes.miojo()

Exemplo7funcoes.paoComSalame()

a = int(input("Digite um numero fih? \n"))
b = int(input("Digite um numero fih? \n"))

Exemplo7funcoes.soma(a,b)

Exemplo7funcoes.maior(a,b)

t=Exemplo7funcoes.dobrar(a)

print(f"O dobro de {a} é {t}")