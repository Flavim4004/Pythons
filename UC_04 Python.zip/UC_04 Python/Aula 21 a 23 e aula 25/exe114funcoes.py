def cadastro(idade,sexo,nome):
    print(f"Usuario {nome} cadastrado cum sucesso")
    print(f"Idade {idade} cadastrado com sucesso")
    print(f"Sexo {sexo} cadastrado com sucesso ")