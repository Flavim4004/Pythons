def dobrar(num,num2):
    dobro=num*2
    soma=dobro+num2
    print(f"o dobro é {dobro} e a soma do dobro com o novo numero é {soma}" )
    


