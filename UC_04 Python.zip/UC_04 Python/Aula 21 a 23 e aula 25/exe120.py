import exe120funcoes
num=int(input("Digite um numero fih! \n"))
exe120funcoes.pouN(num)

