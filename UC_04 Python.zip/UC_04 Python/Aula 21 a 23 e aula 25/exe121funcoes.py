def analisar(num):
    if(num %2 ==0):
        print("É PAR FIH!")
    else:
        print("É IMPAR FIH!")