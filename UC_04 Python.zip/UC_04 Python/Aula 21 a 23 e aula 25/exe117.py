import exe117funcoes
a=int(input("Telefonou para a vítima? \n [1]Sim [2]Não \n"))
b=int(input("Esteve no local do crime? \n [1]Sim [2]Não \n"))
c=int(input("Mora perto da vítima? \n [1]Sim [2]Não \n"))
d=int(input("Devia para a vítima? \n [1]Sim [2]Não \n"))
e=int(input("Já trabalhou com a vítima? \n [1]Sim [2]Não \n"))
exe117funcoes.investigar(a,b,c,d,e)