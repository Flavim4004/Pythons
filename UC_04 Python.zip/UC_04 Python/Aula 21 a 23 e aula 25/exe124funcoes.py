def analise(num,num2,num3):
    maior=int(0)
    if(num>maior):
        maior=num
    if(num2>maior):
        maior=num2
    if(num3>maior):
        maior=num3
    print(f"O maior numero é{maior}")