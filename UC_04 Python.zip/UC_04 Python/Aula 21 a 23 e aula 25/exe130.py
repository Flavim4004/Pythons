import exe130funcoes
exe130funcoes.acabou()