def analise_3(v):
    cal1=v*2
    return cal1
def analise_2(v):
    cal2=v*3 
    return(cal2)  