import exe118funcoes
venda=float(input("Quantos litros tu vai abastecer fih! \n"))
escolha=int(input("Qual combustivel fih! \n [1]Gasolina [2]Alcool \n"))
total=exe118funcoes.posto(venda,escolha)
print(total)