cont=int(100)
while(cont <= 200):
    if(cont %2 == 1):
        print(cont)
    cont=cont+1
