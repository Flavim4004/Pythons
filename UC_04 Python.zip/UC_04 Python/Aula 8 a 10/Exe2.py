cont=int=(0)


while(cont !=3 ):
    tel=float(input("Qual seu numero fih? \n"))
    usu=str(input("Qual seu nome fih \n"))
    cont=cont+1
    print(f"{tel}  telfone cadastrado com sucesso \n {usu}  usuario cadastrado com sucesso ")
