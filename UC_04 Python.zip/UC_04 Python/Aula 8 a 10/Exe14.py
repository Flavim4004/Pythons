cont=int(0)
while(cont !=3):
    num=int(input("Digite um numero fih! \n "))
    if(num==20):
        break