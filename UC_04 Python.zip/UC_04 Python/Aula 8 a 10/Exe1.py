cont=int(0)
soma = 0
while(cont != 3):
    n=int(input("Digite um numero fih! \n "))
   
    cont=cont+1
    soma=int(soma+n)
    
print(f"A soma dos 3 numeros é {soma}")
