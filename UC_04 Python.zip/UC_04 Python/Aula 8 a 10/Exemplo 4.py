idade=int(input("Digite sua idade fih! \n "))
salario=float(input("Digte seu salario fih! \n"))
print("Sua idade é " + str(idade) + " anos e salario é " + str(salario) + "\n" )

#format string
print(f"Sua {idade} é anos e seu {salario} é \n ")
#estrutura de repetiçao enquanto =>while
contar=int(0)
while(contar !=3):
    contar = contar + 1
    salario = int(input("Digte seu salario fih!"))
    if(salario == 2000):
        break