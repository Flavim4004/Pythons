num=int(input("Que numero voce quer começar a contagem fih? \n "))
num2=int(input("Que numero vai terminar a contagem fih \n "))
num3=int(input("De quanto em quanto essa contagem vai rodar fih! \n"))
cont = num
while(cont <= num2):
    print(cont)
    cont+=num3
    
    
    
    
    
    
    
    
