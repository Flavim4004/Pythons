num=int(input("Digite o numero que voce quer ver a tabuada fih! \n"))
cont=int(0)
while(cont <10):
    cont=cont+1
    mult=(num*cont)
    print(f"{num}*{cont}={mult} \n")