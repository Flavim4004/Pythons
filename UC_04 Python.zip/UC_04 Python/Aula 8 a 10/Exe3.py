cont=int(20)
while(cont != 0):
    print(cont)
    cont=cont-2