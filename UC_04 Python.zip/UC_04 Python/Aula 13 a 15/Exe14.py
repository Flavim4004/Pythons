cont=int(0)
for cont in range(0,3,1):
    nome=str(input("Digite seu nome fih! \n"))
    print(f"{nome} Cadastrado com sucesso")