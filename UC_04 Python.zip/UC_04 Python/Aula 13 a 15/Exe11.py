cont=int(0)
soma=int(0)
while(cont <=500):
    cont=cont+1
    if(cont %5 == 0 and cont %2 == 1):
        soma=soma+cont
print(soma)
        