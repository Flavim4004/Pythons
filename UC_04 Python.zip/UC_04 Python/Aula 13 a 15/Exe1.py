cont=int(0)
for cont in range(0,999999,1):
    num=int(input("Digite um numero fih \n"))
    if(num==20 or cont==2):
        print("Parooouuu")
        break
       