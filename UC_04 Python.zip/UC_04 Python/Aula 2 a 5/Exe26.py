reso=int(input("Quem veio primeiro fih? + \n 1. o ovo \n 2.A galinha "))
if(reso == 1):
    print("O ovo ta 1.00 R$")
elif(reso == 2):
    print("O ovo ta 35.00R$")