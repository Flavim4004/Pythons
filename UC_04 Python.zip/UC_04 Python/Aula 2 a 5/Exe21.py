import random
s=random.randint(10,50)
if(s >= 17 and s <= 36):
    print("Deu certo fih")
else:
    print("Não deu certo fih!")