time1=str(input("Qual e seu time fih? \n"))
if(time1 == "Araxa"):
 print("Time campeão")
else:
  print("Não sabe escolher time!")
cidade=str(input("Qual a melhor cidade fih! \n"))
if(cidade == "São Paulo"):
  print("Não sabe escolher cidade!")
else:
  print("Cidade boa")