resp=int(input("Qual jeito voce e rico fih! \n" + "1.Filho de rico" + "\n" + "2.Casamento com rico \n" + "3.é politico \n"))
if(resp == 1):
    print("Verdadeiro")
elif(resp == 2):
    print("Verdadeiro")
elif(resp == 3):
 print("Verdadeiro")
else:
   print("Falso")