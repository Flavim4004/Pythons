resp=int(input("Digite um valor fih! \n"))
div=float(resp + (resp * 0.05))

print("seu salario era " + str(resp) + " e com o reajust de ficou " + str(div))