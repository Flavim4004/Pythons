pes=str(input("Qual seu nome fih? \n"))
idade=int(input("Qual sua idade fih? \n"))
if(idade >= 18):
    print("Foi cadastrado com sucesso com o nome de : " + str(pes) + " maior de idade com " + str(idade))
else:
    print("foi cadastrado com sucesso com onome de :" + str(pes)+ " menor de idade com  " + str(idade))