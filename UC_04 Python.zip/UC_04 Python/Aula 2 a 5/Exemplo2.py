a=int(input("Digite um numero fih!"))
if(a >10):
    print("Deu certo")
else:
    print("Nao deu certo")
if(a >10 and a <20):
    print("Deu certo 1")
elif(a > 20 and a <40):
    print("Deu certo 3")
else:
    print("Deu errado ")

    import  random
    a=random.randint(10,20)