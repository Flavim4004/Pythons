a=int(input("escolha um numero fih"))
b=int(input("Escolha outro numero fih!"))
c=int(input("Escolha mais um fih!"))
cont=int(0)
if(a >=25 ):
    cont = cont + 1
if(b >= 25):
    cont = cont + 1
if(c >= 25):
    cont = cont + 1
print(str(cont) + " são maiores que 25")

