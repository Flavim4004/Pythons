res1=str(input("Voçe fala ingles fih! \n"))
res2=int(input("Quantos anos voçe tem fih? \n"))
if(res1== "sim" and res2 >= 25) or (res1== "sim"):
    print("Verdadeiro")
else:
    print("Falso")