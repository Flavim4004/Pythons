sal1=int(input("Digite seu salario fih! \n "))
sal2=int(input("Digite seu salario fih! \n "))
sal3=int(input("Digite seu salario fih! \n "))
sal4=int(input("Digite seu salario fih! \n "))
maior=int(0)
if(sal1 > maior):
    maior = sal1
if(sal2 > maior ):
    maior = sal2
if(sal3 > maior):
    maior = sal3
if(sal4 > maior):
    maior = sal4
print("O maior salario é " + str(maior))
