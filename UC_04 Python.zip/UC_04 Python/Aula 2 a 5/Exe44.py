perg=str(input("Voce sabe que dia e hoje fih? \n"))
if(perg == "09/09/22"):
    a=str(input("Voce sabe o que comemora nesse dia fih? \n"))
    if(a == "dia do administrador"):
        b=str(input("Voce sabe o que acontecesse dia no senac fih? \n"))
        if(b == "sim"):
            print("então você já sabe da surpresa inesperada, nesse caso a surpresa nem é tão inesperada assim")
        else:
            print("hoje é o dia de uma surpresa INESPERADA")
    else:
        print("hoje é o dia de uma surpresa INESPERADA")        
else:
    print("hoje é o dia de uma surpresa INESPERADA")            