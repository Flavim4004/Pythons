resp=int(input("Quem e mais bonita fih? \n  1.Loira \n 2.Morena \n 3.ruiva 4.careca "))
if(resp == 1):
    print("gosta de cabelo amarelo")
elif(resp==2):
    print("gosta de cabelo preto")
elif(resp == 3):
    print("gosta de cabelo vermelho")
elif(resp==4):
    print("não gosta de cabelo")
else:
    print("Entao tu não gosta de mulher")