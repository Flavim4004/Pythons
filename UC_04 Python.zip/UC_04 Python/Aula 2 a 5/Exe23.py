com1=int(input("Quanto voce vai gastar fih! \n"))
com2=int(input("Quanto voce vai gastar nesse segundo produto fih? \n"))
com3=int(input("Quanto voce vai gastar nesse terceiro produto fih?\n "))
soma=int(com1 + com2 + com3)
media=int(soma/3)
media2=int(media*2)
if(soma > media2 ):
    print("Verdadeiro")
else:
    print("falso")
