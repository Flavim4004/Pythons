resp=str(input("Qual a cor do cavalo do napoleao fih? \n"))
if(resp =="Branco"):
    print("Certa resposta")
elif(resp == "verde"):
    print("errou")
else:
    print("ERRO FIM DO PROGRAMA!")