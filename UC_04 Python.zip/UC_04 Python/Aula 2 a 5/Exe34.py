num=int(input("Digite um numero fih! \n"))
if(num<0):
    print("Negativo não conta \n ")
if (num == 0):
    print("E ZERO \n")
if(num %2 == 0):
    print("é par \n")
if(num %2 == 1):
    print("é impar \n")
    
