cont=int(0)
somapar=int(0)
maiorpar=int(0)
contpar=int(0)
for cont in range(0,4,1):
    num=int(input("Digite um numero fih! \n"))
    if(num %2 == 0):
        somapar=somapar+num
        contpar=contpar+1
    if(num %2==0 and num > maiorpar):
        maiorpar=num
print(f"Foram digitados {contpar} números pares \n A soma desses números pares é {somapar} \n O maior numero par é {maiorpar}")