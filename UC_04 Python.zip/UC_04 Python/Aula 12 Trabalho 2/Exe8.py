compra=int(input("Qual o valor que voce vai gastar fih? \n "))
pag=int(input("Qual a forma de pagamento fih? \n [1]vista ou pix \n [2]cartão de debito \n [3]Cartão de credito parcelado \n"))
match(pag):
    case 1:
        res1=(compra-(compra*0.10))
        print(f"Sua compra de {compra} ganhou um desconto de 10% ficando {res1} ")
    case 2:
        res2=(compra-(compra*0.05))
        print(f"Sua compra de {compra} ganhou um desconto de 5% ficando {res2} ")
    case 3:
        par=int(input("Quantas parcelas voce vai pagar fi? \n"))
        if(par <=3):
            par1=(compra+(compra*0.05))
            res2=(par1/par)   
            print(f"sua compra de {compra} parcelada em {par} de {res2} sendo um total de {par1}")
        elif(par>3):
            par2=(compra+(compra*0.10))
            res3=(par2/par)
            print(f"sua compra de {compra} parcelada em {par} de {res3} sendo um total de {par2}")
        else:
            print("")
    case _:
        print("")