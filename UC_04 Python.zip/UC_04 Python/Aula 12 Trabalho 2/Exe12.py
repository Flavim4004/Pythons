cont=int(0)
maior=int(0)
for cont in range(0,4,1):
    sal=int(input("Digite seu salario fih! \n"))
    if(sal > maior):
        maior=sal
print(f"O maior salario entre as pessoas  citadas é {maior}")