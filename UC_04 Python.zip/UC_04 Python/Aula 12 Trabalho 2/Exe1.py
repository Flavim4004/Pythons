cont=int(0)
somapar=int(0)
somainpar=int(0)
while(cont <3):
    num=int(input("Digite um numero fih! \n"))
    cont=cont+1
    if(num %2 == 0):
        somapar=somapar+num
    elif(num %2 ==1):
        somainpar=somainpar+num
print(f"a soma dos impares é {somainpar} e a soma dos pares é {somapar} \n ")