cont=int(0)
while(cont != 99999):
    num=int(input("Digite um numero fih! \n "))
    cont=cont+1
    if(num==35 or cont ==4 ):
        print("Parou!")
        break
