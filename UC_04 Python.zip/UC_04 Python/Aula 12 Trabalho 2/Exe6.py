cont=int(0)
soma=int(0)
while(cont !=9999):
    num=int(input("Digite um numero fih! \n"))
    cont=cont+1
    soma=soma+num
    if(num==777):
        break
print(f"Foram necessarias {cont} tentativas e a soma dos numeros foi {soma}")