cont=int(0)
for cont in range(0,3,1):
    com=int(input("Quanto tu vai gastar fih? \n"))
    soma=(com+com)
    media=float(soma/3)
    media2=float(media*2)
if(soma>media2):
    print("Verdadeiro")
else:
    print("Falso")
