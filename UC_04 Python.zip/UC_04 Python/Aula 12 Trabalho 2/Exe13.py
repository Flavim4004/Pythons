cont=int(0)
somapar=int(0)
somainpar=int(0)
for cont in range(0,3,1):
    num=int(input("Digite um numero fih! \n"))
    if(num %2==0):
        somapar=somapar+num
    elif(num %2==1):
        somainpar=somainpar+num
print(f"a soma dos números pares é {somapar} e a soma dos números impares é {somainpar}")