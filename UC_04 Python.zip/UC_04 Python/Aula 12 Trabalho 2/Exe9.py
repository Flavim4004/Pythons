cont=int(0)
for cont in range(0,3,1):
    idade=int(input("Qual sua idade fih? \n"))
    nacao=str(input("Qual a sua nacionalidade fih? \n"))
    sexo=int(input("Qual seu sexo fih? \n [1]Masculino \n [2]Feminino \n "))
    if(idade>=18 and nacao == "Brasileiro" and sexo == 1):
        print(f"Sua idade é: {idade} \n sua naçao é: {nacao} \n e se sexo é: Masculino \n que atende os requisitos logo: \n APTO")
    else:
        print("Não APTO fih")