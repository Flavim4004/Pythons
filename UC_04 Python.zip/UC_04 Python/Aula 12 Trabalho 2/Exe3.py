cont=int(0)
cont2=int(0)
cont3=int(0)
cont4=int(0)
cont5=int(0)
while(cont != 9999):
    num=int(input("Digite um numero fih! \n"))
    if(num >=10 and num <=20):
        cont2=cont2+1
    elif(num >21 and num <=30):
        cont3=cont3+1
    elif(num >31 and num <=40):
        cont4=cont4+1
    elif(num >76 and num <=100):
        cont5=cont5+1
    else:
        print("")
    parou=int(input("Tu quer para fih? \n [1]Sim \n [2]Não \n"))
    if(parou==1):
        break
print(f"A contagen de numeros \n  entre 10 e 20  {cont2} \n entre 21 e 30 {cont3} \n entre 31 e 40 {cont4} \n entre 76 e 100 {cont5} ")