cont=int(0)
contnine=int(0)
contseven=int(0)
while(cont<5):
    num=int(input("Digite um numero fih \n "))
    cont=cont+1
    if(num %9==0):
        contnine=contnine+1
    elif(num %7==0):
        contseven=contseven+1
print(f"Foram identificados {contnine} números que são múltiplos de 9 e {contseven} números que são múltiplo por 7")
