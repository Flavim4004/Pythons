peg=int(input("Qual o nome da doença fih? \n [1]Gripe commun \n [2]Dor de barriga \n [3]Dor de cabeça \n [4]Tontura \n"))
match(peg):
    case 1:
        print("repouso, hidratação, medicamentos para aliviar febre e dores, e, em casos mais graves, antivirais,\n caso os sintomas continuar consultar o medico ")
    case 2:
        print("beber bastante líquido, como água e chás calmantes (camomila, erva-doce), e consumir alimentos leves e de fácil digestão, como torradas e bananas,\n caso os sintomas continuar consultar o medico")
    case 3:
        print("A classica neusa ou dipirona, \n caso os sintomas continuar consultar o medico")
    case 4:
        print("medicamentos, exercícios de reabilitação vestibular, e mudanças no estilo de vida, \n caso os sintomas continuar consultar o medico ")
    case _:
        print("Então ta de boas fih!")