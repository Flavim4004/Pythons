tamanho=float(input("Qual o tamanho da cas fih! \n"))
lata=int(0)
while(tamanho > 0):

    
    lata = lata + 1
    tamanho = tamanho - 54
valor = lata *80 
print(f"Falta pintar {tamanho} e gatei {lata} latas e o valor é {valor} ")