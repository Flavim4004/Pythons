cont=int(0)
times1 = ["PSG","Real Madrid","Barcelona","Manchester city","liverpool","flamengo","Vasco","Bota fogo","Palmeiras","São Paulo"]
for cont in range(0,4,1):
    print(times1[cont]+"=>",end="")
for cont in range(5,10,1):
    print(times1[cont]+"=-=",end="")
